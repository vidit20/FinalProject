﻿
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace GroceryManagement.web.Models
{
    [Table(name: "Items")]
    //Item details model
    public class Item
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "ItemID")]                                   // Item Id 
        public int ItemId { get; set; }


        #region Directing to Item Category

        [JsonIgnore]
        [Display(Name = "Item Category")]                            // Item Category
        public int CategoryID { get; set; }
        [ForeignKey(nameof(Item.CategoryID))]
        public Category Category { get; set; }

        #endregion


        [Required(ErrorMessage = "Don't leave {0} Empty!")]
        [Column(TypeName = "varchar(100)")]
        [Display(Name = "Item")]                                     // Item Name
        public string ItemName { get; set; }


        [Required]
        [DefaultValue(true)]
        [Display(Name = "In Stock")]                                 //available in stock or not
        public bool Available { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        [Display(Name = "Price")]                                    // Price of item 
        public float Price { get; set; }


        [Display(Name = "Item Image")]                               // Image URL 
        public string ImgUrl { get; set; } = null;

        #region Navigate Collection to Order
        [JsonIgnore]
        public ICollection<Order> Orders { get; set; }
        #endregion

    }
}
