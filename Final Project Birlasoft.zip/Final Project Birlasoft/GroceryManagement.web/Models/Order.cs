﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GroceryManagement.web.Models
{
    [Table(name: "Order Details ")]

    //Order details model
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Order ID")]                                //Order Id
        public int Id { get; set; }

        // customer Id 
        #region
        [Display(Name = "Customer Id")]
       
        public int CustomerId { get; set; }
        [ForeignKey(nameof(Order.CustomerId))]
        public Customer Customer { get; set; }
        #endregion



        [Display(Name = "Date")]
        [Required]
        [Range(typeof(DateTime), "29-09-2022", "01-10-2022",
                    ErrorMessage = "Please Select the valid date")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime Date
        {
            get;
            set;
        }

        #region Item Link 

        [Display(Name = "Item")]
     
        public int ItemId { get; set; }
        [ForeignKey(nameof(Order.ItemId))]
        public Item Item { get; set; }

        #endregion


        [Required(ErrorMessage = "Don't leave {0} Empty!")]
        [Display(Name = "Quantity(Number of Items)")]
        [DefaultValue(1)]
        public short Quantity { get; set; }



        #region Payment Link

        [Display(Name = "Payment Method")]
        public int PaymentId { get; set; }
        [ForeignKey(nameof(Order.PaymentId))]
        public PaymentMethod PaymentMethod { get; set; }

        #endregion

        [Required]
        [DataType(DataType.Currency)]
        [Display(Name = "Price")]
        public float Price { get; set; }

        //check order placed or not

        [Required]
        [DefaultValue(true)]
        [Display(Name = "Order Placed")]
        public bool OrderPlaced { get; set; }


    }
}
