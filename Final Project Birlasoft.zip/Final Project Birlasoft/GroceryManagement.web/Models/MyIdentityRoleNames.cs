﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace GroceryManagement.web.Models
{
    public enum MyIdentityRoleNames
    {
        //Admin Login
        [Display(Name = "Admin Role")]
        AppAdmin,

        // User Login
        [Display(Name = "User Role")]
        AppUser

    }
}
